package habittracker.taskservice.pomodoro;

public enum Stage {
    WORK, BREAK, DONE
}
