package habittracker.taskservice.model.task;

public enum Status {
    READY, STARTED, PAUSED, STOPPED, RESUMED, COMPLETE
}
