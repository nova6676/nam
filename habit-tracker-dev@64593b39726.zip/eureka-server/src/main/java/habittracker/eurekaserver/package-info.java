/**
 * Микросервис, который отвечает за Eureka.
 * Eureka (Discovery Server) - позволяет регистрировать и отслеживать микросервисы.
 */
package habittracker.eurekaserver;